Project Name: SENTRY-Node v1
Project Version: #6465a889
Project Url: https://www.flux.ai/agamrossen/sentry-node-v1~wa

Project Description:
Acoustic drone detection-and-alert device — PCB port of validated breadboard prototype. ESP32-S3-WROOM-1, 4× I2S MEMS mic plus-array (60mm baselines), e-paper, buzzer/motor/LED alerts, LoRa peer-alert, USB-C charge+flash, 1S Li-Po. Detection + alert only.


Index:

Bottom Copper (Gerber): sentry-node-v1-b_cu.gbr
Bottom Solder Mask (Gerber): sentry-node-v1-b_mask.gbr
Bottom Solder Paste (Gerber): sentry-node-v1-b_paste.gbr
Bottom Silkscreen (Gerber): sentry-node-v1-b_silks.gbr
Board Outline (Gerber): sentry-node-v1-edge_cuts.gbr
Top Copper (Gerber): sentry-node-v1-f_cu.gbr
Top Solder Mask (Gerber): sentry-node-v1-f_mask.gbr
Top Solder Paste (Gerber): sentry-node-v1-f_paste.gbr
Top Silkscreen (Gerber): sentry-node-v1-f_silks.gbr
Mid-Layer 1 (Gerber): sentry-node-v1-in1_cu.gbr
Mid-Layer 2 (Gerber): sentry-node-v1-in2_cu.gbr
Drill Holes (Excellon): sentry-node-v1.drl
Electrical Test Netlist (IPC-D-356): sentry-node-v1.d356
Component Positions, for assembly (Pick and Place, CSV): pick_and_place.csv

Bill of Materials: multiple versions are provided optimized for various contract manufacturers:

Bill of Materials (AdvancedCircuits): BOM/agamrossen-sentry-node-v1-BOM-V6465a889-AdvancedCircuits.csv
Bill of Materials (AllPCB): BOM/agamrossen-sentry-node-v1-BOM-V6465a889-AllPCB.csv
Bill of Materials (Elecrow): BOM/agamrossen-sentry-node-v1-BOM-V6465a889-Elecrow.csv
Bill of Materials (Eurocircuits): BOM/agamrossen-sentry-node-v1-BOM-V6465a889-Eurocircuits.csv
Bill of Materials (Flux): BOM/agamrossen-sentry-node-v1-BOM-V6465a889-Flux.csv
Bill of Materials (JLCPCB): BOM/agamrossen-sentry-node-v1-BOM-V6465a889-JLCPCB.csv
Bill of Materials (PCBWay): BOM/agamrossen-sentry-node-v1-BOM-V6465a889-PCBWay.csv
Bill of Materials (Seeed): BOM/agamrossen-sentry-node-v1-BOM-V6465a889-Seeed.csv

